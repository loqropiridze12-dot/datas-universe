# Data's Universe

A responsive, single-file educational website built with HTML, CSS, and JavaScript.

## Preview locally
1. Extract `datas_universe.zip`.
2. Open `index.html` in a web browser.

## Publish free with GitHub Pages
1. Sign in at https://github.com/ and create a **new public repository** named `datas-universe`.
2. On the repository page, choose **Add file → Upload files**.
3. Upload `index.html` (and this README if you like), then commit the changes.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then click **Save**.
7. Wait for GitHub Pages to publish. Your address will look like:
   `https://YOUR-USERNAME.github.io/datas-universe/`

## Help Google discover it
1. Open https://search.google.com/search-console/
2. Add the published GitHub Pages URL as a **URL-prefix** property.
3. Verify ownership using one of the methods Search Console offers. For a GitHub Pages site, the HTML file or HTML tag method may be easier than DNS if available; follow the exact instructions Google shows.
4. Use **URL Inspection** to inspect your homepage URL and select **Request indexing**.
5. Keep the site public, add useful original content, and link to it from relevant public pages. Indexing and ranking are not guaranteed and may take time.

## Important note about the content
Data's biography, dates, stories, and quotation are fictional and are labeled as such throughout the website. Replace or expand them if you have real, sourced information about a person named Data.
